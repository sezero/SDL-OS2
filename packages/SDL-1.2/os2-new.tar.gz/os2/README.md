LIB-SDL-2014
============

SDL Libraries version 1.2.15. Simple DirectMedia Layer library for OS/2 and eComStation 

LICENSE
===============
* GNU LGPL V2

COMPILE TOOLS
===============
Note that Open Watcom 1.9.0 release miscompiles SDL-1.2.15 somehow (or
something is wrong in its crt) therefore a newer version is needed:

* Open Watcom snapshot builds from the 'official' perforce repository:
  - https://efbe.musca.uberspace.de/

* Open Watcom 'unofficial' V2 fork by Jiří Malák:
  - http://open-watcom.github.io/open-watcom/
  - https://github.com/open-watcom/
  - https://github.com/open-watcom/travis-ci-ow-builds

AUTHORS
===============
 * Port: Andrey Vasilkin

LINKS
===============
* 
